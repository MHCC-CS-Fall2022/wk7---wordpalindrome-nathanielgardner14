// Filename: testPalindrome.cpp
// Created by: Nathaniel Gardner
// Purpose: Driver file that utilizes the stack and queue classes. A sentence is input by 
// the user, and it is then determined whether it is a word by word sentence palindrome.

#include <iostream>	// cin, cout
#include "stack1.h"	// stack class
#include "queue1.h"	// queue class
using namespace std;
using namespace palindrome_ngardner;

// Driver File Prototypes
int sentenceEdit(string, string[]);
// Postcondition: The sentence the user created is sent over and edited to be usable.
// The entire sentence is converted to lowercase. Punctuation is erased from 
// the sentence. Then the sentence is spliced into individual words in an array 
// that is returned by reference. Returns number of words in the sentence.
bool isPalindrome(string[], int);
// Postcondition: Inserts the words from the sentence (string array) into a stack and a queue.
// Then the function checks if the words at the front of the queue and top of stack are
// the same, then pops both, pushing the queue forward through the sentence and the stack 
// backward until they are finished. If there was any discrepancy, the function returns
// false, otherwise returns true.

int main()
{
	int wordLimit = 30;
	int wordCount;
	char repeat;
	string sentence;
	string wordList[wordLimit];
	
	do
	{
		cout << "\nEnter a sentence:\n";
		getline (cin, sentence);
		wordCount = sentenceEdit(sentence, wordList);
		if (isPalindrome(wordList, wordCount) == true)
			cout << "The sentence is a word palindrome.\n\n";
		else
			cout << "The sentence is not a word palindrome.\n\n";
		cout << "Do you want to test more sentences? (type 'y' or 'n') ";
		cin >> repeat;
		cin.ignore(80, '\n');
	} while (repeat == 'y'); 
	return 0;
}

int sentenceEdit(string sentence, string wordList[])
{
	int wordCount = 0;
	
	// Converting to lowercase
	for (int i = 0; i < sentence.size(); i++)
		sentence.at(i) = tolower(sentence.at(i));
	// Removing all punctuation throughout the sentence
	for (int i = 0; i < sentence.size(); i++)
	{
		if (sentence.at(i) == '.' || sentence.at(i) == '!' || 
		    sentence.at(i) == '?' || sentence.at(i) == '"' ||
		    sentence.at(i) == ',')
		    {
		    	sentence.erase(i, 1);
		    	i--;
		    } 
	}
	// Splitting sentence into words in a string array
	sentence += " ";
	for (int i = 0; sentence.size() != 0; i++)
	{
		if (sentence.at(i) == ' ')
		{
			wordList[wordCount] = sentence.substr(0, i);
			sentence.erase(0, i+1);
			i = -1;
			wordCount++;
		}
	}
	return wordCount;
}

bool isPalindrome(string sentence[], int wordCount)
{
	stack<string> s1;
	queue<string> q1;
	bool palindrome;
	
	for (int i = 0; i < wordCount; i++)
	{
		s1.push(sentence[i]);
		q1.push(sentence[i]);
	}
	
	palindrome = true;
	for (int i = 0; (i < wordCount) && (palindrome == true); i++)
	{
		if (s1.top() != q1.front())
			palindrome = false;
		s1.pop();
		q1.pop();
	}
	return palindrome;
}
